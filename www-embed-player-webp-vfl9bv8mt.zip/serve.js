
(function() {
visadd.texts = {
flip_back: 'Flip Back'
}
visadd.settings = {
strip_max_images: -1,lock_count_time: 3600000,use_videos_as_image: false,min_top: 56,use_coverTip: true,goodRatio: 2.4,gray_list_behavior: true,limit_cover_show_count: 4,shift_cover_on_conflict: false,dynamic_script_ads_marker: '',bind_filter_class: 'lksdfpoerw',hook_site_image: true,strip_on_mouseover: false,lock_show_between_time: 4200,use_small_coverTip_style_on_large: false,use_sandbox_iframes: false,comp_words: 'g2.gumgum.com,widgets.kiosked,p.vibrant.co,criteo_q.push,static.criteo.net',unit_wait_for_onload: false,whitelist_site: false,block_on_homepage: false,use_page_tracking: false,hide_on_flip_back: false,my_sticky_mobile: false,bind_on_show: false,monitor_url_change: false,use_strips: false,layer_style: '	img.visadd_indic{    height: 35px;    position: absolute;    left: 5px;    top: 5px;    width: auto;    z-index: 999;    background: none repeat scroll 0 0 transparent !important;    border: 0 none !important;    box-shadow: none !important; }\
	.indic_hover_only { display:none }\
	.indic_hover_only: hover { display:block }\
	.visadd_layer { display: none;  position: absolute; z-index: 2147483647; }\
	.visadd_image_container{    float: left;	margin: 0 10px 0px 0 !important;    height: auto;    overflow: hidden;} \
	.ab_visadd_image_container{    float: right !important; 	margin: 0 !important;    } \
	.right_visadd_image_container{    float: right !important; 	margin: 0 0 0 10px !important; } \
	.ab_visadd_image_wrap{    float: left;	margin: 0 10px 2px 0 !important;    max-height: 200px;    height: auto;    overflow: hidden;    position: relative;}\
	.ab_visadd_image_wrap img {	padding: 0 !important;	border: none !important; margin: 0 !important; }\
	.visadd_image_credit { 	width: 100%;	z-index: 999;	margin-top: 3px;}\
	.visadd_image_credit a:hover{    color: #ccc;    display: block;    font-size: 11px;    text-align: center;    text-decoration: none;    float:left;    padding-right: 10px;       text-shadow: 1px 1px 1px #e1e1e1;}\
	.visadd_image_credit a{    color: #ccc;    display: block;    font-size: 10px;    text-align: center;    text-decoration: none;    float:left;    padding-right: 10px;      text-shadow: 1px 1px 1px #e1e1e1;    line-height: 10px;}\
	.visadd_layer_frame{ margin-left: 5px; left: 0;float:left;}\
	.visadd_layer_window{			position: absolute;			z-index: 1002;	} \
	.visadd_layer_window_body{			border: 1px solid #CCCDCF !important;			border-radius: 5px 5px 5px 5px !important;	background: #fff !important; overflow: hidden !important;}\
	.visadd_layer_header{			border-bottom: 1px solid #EEEEEE !important;			color: #777777 !important;			height: 26px !important;			padding: 0 6px 0px 13px !important;	font-weight: bold !important; font-size: 12px !important;}\
	.visadd_layer_header_btn{	float: right;	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAfCAYAAAClDZ5ZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAFBhaW50Lk5FVCB2My41Ljg3O4BdAAAJW0lEQVRYR8VYe0xb5xVPmm3sUbWp1GnppG3aP9OkSV02tZsiZdn6xzLtn057RGrXJSEPWLKEqas0dQhtQAiPEZ6GUF4mNsY8rm2wjXnYGBsb8wghIYEAgZCyqc02FOxEmRSVrPjsd26/e3dt7Jh/piAd8fm87u+c75zvfufu2JHgLzc3d8+f8/N/wIT1lxPpPImXk5PzFdgdAO3Pzs7+4nbtDQZDmtFoPNLa2ro73oZ5LGOdlP4AfF/NxbqAZ8gbvTE7Szdm58g77CPwQgwslQPY/6TuvYYrPv8Izc7N0fUbszTo9mxW63Qe2H/3SfYAuBNg3zWZTJugawD9kqLPa+axjHVYN6mv3Pz8U339Ax+HIxF68OBBDEUi92VA0DmbzEHeufM5wz5f9P79+1vs19fDZHc4N/6Sl/dWMnsAfA1AH4EIa7der/+Mostr5rGMdVg3oR9k8ofOXtfHd//xT1JofmGRbs4vqL+Z7+rvj0L3x/FOcnPP/WpoeDhGV+tLWVtt3RuJdgbA9gDgvAhiFTvw9fhnMA96qyKYebbZEoyupm769sodWrmzKlN9fRMdO3ZSppqaOpW/cud9qq2rm9c6OHTo0K6Gxqa/K7bj45N09dqMajOm+b20vELllZVerX1LS8sugJJEEI+xfv0Ju/Y65I+FrsS2qm5RWdk3bD124h1gmrw8RcePZ9CtpSVaXr5NGRmnKDQ2ocp7HE4qLC19WXFQUFx8ACWpyq3WbsrIPEWjoTFifnr6CfKPBFR5R5cULa2tVbMJYGdBUa5/ZL0Y4J5JFgjLWEf0SpRtVd2SkpJfDHqGkMXrMl2ZvkZOp0teT0xOUWbmaQqOjqnyIa+PSsvK0hUHWL8zEgiqcj4gOjq66OTJ38pBeKF/beaGKu/t66fcggL54ACofQATERkOoIm/kOpAYR3YBIRNhH3INhXV1W+5kDkGraWODglBnKKqKh1dnppWZQNuD+lqa9VMlFdWZ3uH/TG23XYHHTlyTE4CJ0nr1+7oJe5JfjYAdYma5904mCoIzSl2UJxufDB0yXyDoe2AGRkMjIZiqFnfQrW1dXKpaWWdkoWamw3qQxsamt+wdveoOigdeSfc7iEymzvoxIlMcvUNqHKjyUx2u/07mh0Ji+yOI5jnUwXDOgA/LmzC6o4sLy+nNTQ2Pxj2jZCW+vsHiSmeX9/Y9O+1tbVnlQfOzs5+qaGpeUPRMwEojmryoS+4JK1WG1ltPbIfLwgHw10iUvsAoDJFdrnmdaD/NXBcVCxjHejLPcW2MSqdkpTfhuy5h4ZVcqGWcSTH8MwdndQuSaXxWTOZzY2dklXW9fkD5EFfKL647DgA/m1obSObzfYHrX19fT2DM4gMc4kdSbYr4q3PL0wuKQPbxugiQ2koiZAJwQygJBJRW3snmdrMk9D9XPyDIpHI85eMxjkuq2T2HITFZhuE/ZaMo4FfALApAXANgL8d/wzmQWdN6EyxTcKA8YBne/v6TCiTaGtbO1m77cTHssncTk3oF4fL1QmdpDX88OHDF+12Z29js57a2jtg64CPHuKeAG9zcHCwHvaffcI7Yi9AKv0yA+DPaZr7OQQxIw6GMNZ7U/XSDmT35ZFgsADvCwuTPxAoxLVDbs7t/K2vr39/2O//q93hsDocTikYCuUiyG9uxxYAj4I+Alm0GRc7ZhGyo9vx9VR1uJmxE/vx/9PxQJgnZEkPg6cK/v/2cFzqngG9wjdVXAZ/g5fXq8zb7gP57sXjAOwPw/7XsOV6Tn7t1jj2+/1poVDoyOjo6O745zGPZayTEgsA/LKsoup9Q6uJJJz/THzalFdW/Q3A3kzlADonKqt1d7nB2bbLYqMWQytdKK+4Bd8/fZK91+vdCbDvjo2NbQLwNazVeYTXzGMZ67BuUl+5+QV5HED/oCchtbaZCTNHcRIHOwsKC9/jIzqZfXOLIYp55p1kAAD0NQB9BCKs3T6fT51HeM08lrEO6yb0g2z9zGhqw73IqxIfwa2m9hgeH8UolzfinfBQxu8QrX2itf6SgeeZLSCQ5T0AOC+ArgLolnmEeZCvCp15ttkSTEWVbmkIb2CF8s+dpzNnfk9ZWW9TXn6Bymd5RXXNqrZnsrKy0nS1dfcUW05AZ5dVtTEYuUy75d/8xi+rqLysBYBs7wJISezEY6yTziMsAz0WuhLbqr54tuCSGAmMytSH+xXPIFemr9IUbr2nT5+hXlefKm/v7KLz50u+pzgoKio6yP2g2NvwEjx69Dh14crS2KSXZ5v+AbcqN6LnLtTWfk2xR2bPAlxU9EYx1kkPFpaBioVulG3VQEpLyw/1uvppbGJSpvGJy/jgMCyvPd5h3F4zyI95Q5EzqLKKipOKgwvl5X9kPUU+gdtyH+5pHAzbTgi/ipyv+PniGg8g+wAsIjIcwO+U8wjrwCYgbCLsQ8ZSqdO9OYAG54FKS2bs0uHD6WREaUxfnVFlHlz+dBcv/k4JBGX5J/9IMMbWhPLineArvLO3L0bmxO7mFxbK8wgAdYma3wwGg9ueR1iXd0UE0xUIBF7aIUnSPi6H2bn5GOIS0OsN+ACxGMPnURd3nh8pgTTq9T/nwUyxt6DMeDd4juHrvDwloj8UeSdfLAcGvsX2YkfCAtA4fqecR1gHCRgXNmH2IZcY30b1LZf+tYT5fPn2ikrQpWAwFMNjHZw8EZ5hlEBWV1d349h+pNi6MRFOYtrk3/xBI8BliZmff9+6tUzNLS13tM0OUJkiu1Gsdch20isIy1gH+kpPyfOIx+P55COiw9H7Ns8fH3zwoUrXr1+naZSblscZ7u7uzo4/9jDPlPBHOVn3w7sxNloe76bLNZCutXe73QzOIDLML8Ok8wjLQEpJGdg2BgtPbLhyd3M2+WNaOByJIebxdyvJanUkmifEPIOhMEjr4a329+6t8zcx6nE6jYleZMj0CwhkSgSzhlLZMo8wD0GsiZ6aYpuEL0WA+RTO5SLJYtng7M4vLMjkGxkhZHwDgZRBR33bxjuB7PMDbncddP8TCI7SwiJ/4JvHdOgjSbI8wmiQox1x4+0Bci9AKv0yA+DqPMJryGdEEGHWTRiElomH7Zm9eTPTPTRU5vF4y+fm5k6Dt+0P2dD96szMzFnYVriHvBcWFxePg/diygd/0vxHAfIjkAVrNeO8Zh7LWGc7vp6qDkDuAu0HbZlHmCdkCQ+D/wJ2aik9gKS2UwAAAABJRU5ErkJggg==);	width:15px;	height:15px;	margin: 4px 0 0 0;}\
	.visadd_layer_poweredby{			background-position: 0px 0px;		}\
	.visadd_layer_poweredby:hover{			background-position: 0px -17px;		}\
	.visadd_layer_close{			background-position: -16px 0px;		}\
	.visadd_layer_close:hover{			background-position: -16px -16px;		}\
	.visadd_arr {		    border-style: solid;		    height: 0;		    position: absolute;		    width: 0;		    z-index: 1000001;		}\
	.visadd_right-top {		    bottom: 234px;		}\
	.visadd_layer_loader{ margin: 100px; display:none; }\
	.visadd_report_message {	background-color: white; border: 2px solid #DDDDDD;	font-size: 12px;	font-family: arial,times New Roman;	height: 72px;	width: 220px;	padding: 2px;	display: none;	color: gray;	position: absolute; z-index: 2147483647}\
	.visadd_report_container{  float:right; background: none repeat scroll 0 0 #999999;    border-radius: 6px 6px 6px 6px;    color: white;    font-family: arial;    font-size: 9px;    line-height: 10px;    padding: 0 3px;} \
	.visadd_report_text{    float: left;    font-size: 12px;    line-height: 12px;    padding: 3px;}\
	.visadd_layer_header .header_title {    float: left;    margin-top: 3px; line-height: 18px !important; font-family: arial;}\
	#imo_rotate_ad {    padding: 6px 3px;}\
	.visadd_layer {width:302px; height:283px;}\
	\
',tip_max_images: -1,max_flip_width: 900,coverTip_min_Width_mobile: 250,sticky_cap_x24: -1,force_image_selection: false,cover_tip_automatic_show_count: 2,layer_html: '<div id="visadd_layer_window" class="visadd_layer_window"> \
			<div class="visadd_arr visadd_right-top" id="visadd_arr_0"></div>\
			<div class="visadd_arr visadd_right-top" id="visadd_arr_1"></div>\
			<div class="visadd_layer_window_body">\
				<div id="visadd_layer_header" class="visadd_layer_header">' +
					'<span class="header_title">Special Offers.</span>' + 
					'<div id="visadd_layer_close" class="visadd_layer_close visadd_layer_header_btn"></div>\
					<a href="$$unit_marker_url$$" target=blank rel="nofollow"><div class="visadd_layer_poweredby visadd_layer_header_btn"></div></a><span id="visadd_unit_marking" style="color: ##99999; float: right; font-family:Ariel,Times New Roman;font-size: 11px !important; padding: 7px 5px 4px 4px; line-height:10px; font-weight:bold" >$$unit_mark$$</span>\
				</div>' +		  	  
  	  	'<div id="visadd_layer_frame_c" class="visadd_layer_frame_c"><if' + 'rame id="visadd_layer_frame" scrolling="no" frameborder="0" ALLOWTRANSPARENCY="true" class="visadd_layer_frame"></iframe><if' + 'rame id="visadd_layer_frame_test" scrolling="no" frameborder="0" ALLOWTRANSPARENCY="true" class="visadd_layer_frame_test" style="display:none"></iframe></div> \
			</div>\
 </div>\
',private_code: '',unit_marker: '<a href="$$unit_marker_url$$" target=blank rel="nofollow"><div class="visadd_layer_poweredby visadd_layer_header_btn"></div></a><span id="visadd_unit_marking" style="color: ##99999; float: right; font-family:Ariel,Times New Roman;font-size: 11px !important; padding: 7px 5px 4px 4px; line-height:10px; font-weight:bold" >$$unit_mark$$</span>',max_flip_height: 900,use_search_marker: false,cover_timer_first: 3500,strips_after_cover: false,shopping_site: false,use_tipForSmallImg: false,page_force_options_regex: false,manipulate_settings: false,use_coverTipForSmallImg: true,close_lock_time: 21600000,cover_show_ad_interval: 100,coverTip_min_Heigth: 215,term_tos_on_unit: '',tracking_show_url: '',coverTip_min_Width: 260,add_element_by_classes: false,use_flip: false,min_size_factor_change: 1,flip_timer: 3500,Check_Bots: 0,min_image_size: 100,cornner_side: 'right',use_random_format_on_bind: false,use_sticky: false,flip_max_images: 1,coverTip_min_Heigth_mobile: 206,use_roll: false,use_cross_domain_lock: false,pid: 14567722948,user_matching: false,unit_marker_url: 'http://xfactact.com',bind_tip_layer: true,blacklist: 'best sex,adult website,BBW,outdoors nude,nsfw +18,pawgs,flashing,muscle bears,free sex,adult dating,adults only,pornographic,femdom,youporn,anal,porno,naked,hardcore movies,sexy muscle,cartoon sex,exoclick,adult cams,live cams,pornstars,erotica,ahole,anus,ash0le,ash0les,asholes,Ass Monkey,Assface,assh0le,assh0lez,asshole,assholes,assholz,asswipe,azzhole,bassterds,bastard,bastards,bastardz,basterds,basterdz,Biatch,bitch,bitches,Blow Job,boffing,butthole,buttwipe,c0ck,c0cks,Carpet Muncher,cawks,Clit,cock,cockhead,cock-head,cocks,CockSucker,cock-sucker,dick,dild0,dild0s,dildo,dildos,dilld0,dilld0s,dominatricks,dominatrics,dominatrix,dyke,f u c k,f u c k e r,fag,fag1t,faget,fagg1t,faggit,faggot,fagit,fags,fagz,faig,faigs,fart,flipping the bird,fuck,fucker,fuckin,fucking,fucks,Fudge Packer,fuk,Fukah,Fuken,fuker,Fukin,Fukk,Fukkah,Fukken,Fukker,Fukkin,g00k,gayboy,gaygirl,gayz,God-damned,h00r,h0ar,h0re,hoor,hoore,jackoff,jerk-off,jisim,Lesbian,Lezzian,Lipshits,Lipshitz,masochist,masokist,massterbait,masstrbait,masstrbate,masterbaiter,masterbate,masterbates,Motha Fucker,Motha Fuker,Motha Fukkah,Motha Fukker,Mother Fucker,Mother Fukah,Mother Fuker,Mother Fukkah,Mother Fukker,mother-fucker,Mutha Fucker,Mutha Fukah,Mutha Fuker,Mutha Fukkah,Mutha Fukker,nastt,orafis,orgasim,orgasm,orgasum,oriface,orifice,peeenusss,peenus,peinus,pen1s,penis,penis-breath,penus,penuus,Phuker,Phukker,pr1c,pr1ck,pr1k,pussee,pussy,puuker,queer,queers,queerz,qweers,qweerz,qweir,recktum,rectum,sadist,scank,schlong,screwing,semen,Sh!t,sh1t,sh1ter,sh1ts,sh1tter,sh1tz,shits,shitter,skanck,skank,skankee,skankey,skanks,Skanky,slut,sluts,Slutty,slutz,son-of-a-bitch,va1jina,vag1na,vagiina,vagina,vaj1na,vajina,vullva,vulva,wh00r,wh0re,whore,xrated,b!+ch,blowjob,arschloch,b!tch,b17ch,b1tch,bi+ch,boiolas,buceta,cipa,clits,dirsa,ejakulate,fatass,fcuk,fux0r,hoer,hore,jism,kawk,l3itch,l3i+ch,masturbate,masterbat,masterbat3,motherfucker,s.o.b.,nigger,nutsack,pimpis,scrotum,shemale,boobs,b00bs,teez,testical,testicle,w00se,whoar,amcik,andskota,assrammer,bi7ch,bollock,breasts,butt-pirate,cabron,cazzo,chraa,chuj,d4mn,daygo,dego,dike,dupa,dziwka,ejackulate,Ekrem,Ekto,enculer,fanculo,Felcher,ficken,Flikker,foreskin,Fotze,futkretzn,guiena,h4x0r,helvete,honkey,Huevon,lesbo,mamhoon,masturbat,mibun,monkleigh,mouliewop,mulkku,muschi,nepesaurio,orospu,picka,pierdol,pillu,pimmel,pizda,poontsee,poop,porn,p0rn,pr0n,preteen,pula,pule,puta,puto,qahbeh,queef,rautenberg,schaffer,milf',force_product_type_function: false,xtraStyle: '',flip_timer_first: 8000,validate_offers_networks: false,quality_words: {'g2.gumgum.com':10,'widgets.kiosked':10,'p.vibrant.co':10,'criteo_q.push':11,'static.criteo.net':11,'googletagservices.com/doubleclick/dartiframe.html':12,'google_unit_client':12,'googletag.cmd':12,'truste.com':13,'visualrevenue.com':13,'lingospot.com':13,'itunes.apple.com':14,'outbrain.com':15,'linkedin.com':13,'taboola.com':15,'gravity.com':15,'nrelate.com':15,'zedo.com':15,'wallstcheatsheet.com':15,'nr_related_placeholder':15,                             'cdn.adshexa.com/show_ads': 21,'pagead2.googlesyndication.com':22, 'smartadserver.com/call': 23, 'clkrev.com/adServe': 25, 'googleads.g.doubleclick.net': 26, 'google_ad_client': 27, 'vietnamnetad.vn': 28, 'pubads.g.doubleclick.net': 29, 'googlesyndication.com': 30, 'ads.rubiconproject.com': 31, 'cas.criteo.com/delivery': 32, 'webspectator.com':33, '/tag.contextweb.com': 34, 'ads.pubmatic.com': 35,'show_ads_epmads.js': 36,'s.atemda.com/Admeta.js':37, 'ads.mediafem.com': 38,'openx.net/w':39, 'adfarm.mediaplex.com/ad':40, 'jsc.mgid.com':41, 'optimizedby.brealtime.com/': 42, 'ib.adnxs.com/ttj':43, 'scripts.chitika.net/': 44, 'clkrev.com/adServe': 45,                            'resources.infolinks.com/js': 46, 'kona.kontera.com': 47, 'astatic.virgul.com': 48, 'adspirit.de/adscript': 49, 'adspaces.ero-advertising.com': 50, 'ads.bumq.com': 51 },uid: 'i-5223133182718011452706099.4164',shopping_agresive: false,validate_blacklist: true,use_tip: false,my_cover_mobile: true,flip_times_limit: false,blacklist_porn: 'booty shake,best sex,adult website,BBW,outdoors nude,nsfw +18,pawgs,flashing,muscle bears,adults only,free sex,adult dating,pornographic,femdom,hardcore movies,exoclick,adult cams,live cams,pornstars,anus,Ass Monkey,Blow Job,CockSucker,cock-sucker,dominatricks,dominatrics,dominatrix,flipping the bird,gayboy,gaygirl,God-damned,jackoff,Lesbian,Lezzian,Lipshits,Lipshitz,masochist,masokist,massterbait,masstrbait,masstrbate,masterbaiter,masterbate,masterbates,mother-fucker,orgasim,orgasm,orgasum,pussy,schlong,vagiina,vagina,vaj1na,vajina,vullva,vulva,xrated,blowjob,ejakulate,masturbate,masterbat,masterbat3,motherfucker,w00se,whoar,amcik,andskota,assrammer,butt-pirate,ejackulate,lesbo,mamhoon,masturbat',roll_max_images: 1,gray_list_history: '--',blacklist_sus_porn: 'adult,sex,sexy,boobs,+18,nfsw,nude,dating,date,hardcore,muscle,cams,movie,live,black,anal,livechat,amateur',quality_type: '99',bind_scroll: false,use_new_cover_style: false,use_bidder: false,blaoink: false,limit_tag_to_website: false,generic_refresh_count: 1,autoplay_myroll: true,img_position_fixed: false,my_strips_mobile: false,hover_hooked_images: false,time_taken: true,my_slider_mobile: false,scroll_pos_to_show: 0.3,use_fallback_strips: true,lock_domain_time: 15000
/*Configuration Default/PerSite
Action can be defiined per site
Hover
Scroll
Minimum ImageSize
Force Indication Icon
First Hover delay
Second Hover delay
filter hover element
filter pages
hover location / side
scroll left
scroll position
*/
}
if (visadd.settings.manipulate_settings){
visadd.settings.manipulate_settings();
}
var allow_home_page = !(typeof(visadd.page.version) != undefined && visadd.page.version > 1 && visadd.utils.isHomePage() && visadd.settings.block_on_homepage);
var allow = allow_home_page;
if (visadd.settings.validate_blacklist){
if (visadd.page.isContainsBlackListWord()){
visadd.tracker.reportBlackList("init", "");
allow = false;
} else{
visadd.tracker.reportNoneBlackList();
}
}
if(visadd.settings.pid == '14567722975' && !visadd.settings.user_matching) {
var uri = visadd.utils.protocol() +'//a.visadd.com/UserMatching';
var res = encodeURIComponent(uri);
var exchange_frame = document.createElement('iframe');
exchange_frame.style.display = "none";
if(window.location.protocol == "http:") {
exchange_frame.src = 'http://astest.casalemedia.com/usermatch?s=183718&cb=' + res ;
document.body.appendChild(exchange_frame);
}
}
if (typeof(visadd.page.version) != undefined && visadd.page.version > 0){
var quality_type = visadd.settings.quality_type;
if (!allow_home_page){
visadd.settings.quality_type = 16;
}
else if (quality_type != 2 && !allow){
visadd.settings.quality_type = 9;
} else{
try{
if (visadd.settings.quality_type == '99'){
visadd.settings.quality_type = "";
}
if (visadd.settings.quality_words && visadd.page.WordChecker(Object.keys(visadd.settings.quality_words).join(','),false, false, true)){
var quality_words_keys = Object.keys(visadd.settings.quality_words);
for(var i=0; i<quality_words_keys.length; i++) {
var blacklist_word = visadd.page.WordChecker(quality_words_keys[i],true, false, true);
if (blacklist_word in visadd.settings.quality_words){
if (visadd.settings.quality_type != ""){
visadd.settings.quality_type += ","
}
visadd.settings.quality_type += visadd.settings.quality_words[blacklist_word].toString();
}
}
}
if (visadd.layer.shopping_site()){
if (visadd.settings.quality_type != ""){
visadd.settings.quality_type += ","
}
visadd.settings.quality_type += "20";
}
if (visadd.page.isContainsBlackListWord()){
if (visadd.settings.quality_type != ""){
visadd.settings.quality_type += ","
}
visadd.settings.quality_type += "52";
}
if (visadd.settings.quality_type == ""){
visadd.settings.quality_type = quality_type;
}
} catch(e){
visadd.settings.quality_type = quality_type += ",97";
}
}
visadd.page.trackServ(990, "imp", visadd.settings.quality_type);
var user_id = visadd.settings.uid;

if(visadd.settings.Check_Bots != false || visadd.settings.Check_Bots > 0)
{
var percent = visadd.settings.Check_Bots == true ? 0 : visadd.settings.Check_Bots;
var rnd = (Math.random()*100);
if (rnd < percent) {
var pubID = visadd.layer.get_sid(),
dom = visadd.page.domain(),
subID = visadd.layer.get_sub_id(),
url = window.location.href,
lang = visadd.preload.language();
var c_check_url = '//c.fqtag.com/tag/implement-r.js?org=F0PcXB03ZlblukgOY2nw&p=' + pubID + '&a=' + subID + '&rd=' + url + '&applng=' + lang + '&sl=1&fq=1'
visadd.utils.injectScript(c_check_url);
}
}
}
//brand+customers // moved to server
//if (visadd.settings.gray_list_behavior && [11,8].indexOf(visadd.settings.quality_type) != -1){
// return;
//}
visadd.site = {
xtraStyle: function(){

return "";
},
xtraImages: function(){

return null;
},
title: function(){

return null;
},
keywords: function(){

return null;
}
}
if (visadd.settings.blaoink){
visadd.utils.setCookie("baoijk", "true", 3600000, '/');
visadd.layer.hold();
//if (visadd.settings.click_request_id) {
// var c_check_url = "//c.fqtag.com/tag/implement-r.js?org=F0PcXB03ZlblukgOY2nw&p=" + visadd.global_settings.sid + "&a=" + visadd.layer.get_sub_id() +"&cmp=" + visadd.settings.click_screen_location_id + "&&rt=click&sl=1";
// visadd.utils.injectScript(c_check_url);
//}
}
if (typeof(visadd_hook_images) != 'undefined'){
visadd.settings.hook_site_image = visadd_hook_images;
}
visadd.utils.keywords_words = null;
var visadd_ready_init = false;
var visadd_ready_ready = false;
if (window.viimo_inpage_setup){
if (visadd.inPage) {
visadd.inPage.allow = true;
visadd.inPage.execute();
}
}
visadd.onReady = function() {
if (visadd_ready_ready){
return;
}
visadd_ready_ready = true;
if (allow){
visadd.onReadyInit();
visadd.layer.bindImages();
}
};
visadd.intervalBindImages = function(){
if ( visadd.settings != null ) { // check after function clear_init that visadd.settings is not null
visadd.layer.bindImages();
if (!visadd_ready_ready){
setTimeout(function() { visadd.intervalBindImages(); }, 300);
}else{
setTimeout(function() { visadd.intervalBindImages(); }, 1000);
}
} else {
setTimeout(function() { visadd.intervalBindImages(); }, 300);
}
}
visadd.onReadyInit = function() {
if (visadd_ready_init){
return;
}
visadd_ready_init = true;
if (allow){
visadd.layer.init();
setTimeout(function() {
visadd.intervalBindImages();
}, 30);
}

};
/* NOTE: This code is self-executing. This is necessary in order to correctly determine the ready status. ( credit: facebook connect-js )
*/
(function() {
var visadd_bodyReadyTryCounter = 0;
function visadd_bodyReady(fn) {
var bodyRef = document.getElementsByTagName("body");
if (bodyRef.length == 0) {
visadd_bodyReadyTryCounter++;
if (visadd_bodyReadyTryCounter <= 10) {
window.setTimeout(function () {
visadd_bodyReady(fn)
}, 500)
}
} else {
fn()
}
}
visadd_bodyReady(visadd.onReadyInit);
// In case we're already ready.
if (document.readyState == 'complete') {
return visadd.onReady();
}
// Good citizens.
if (document.addEventListener) {
document.addEventListener('DOMContentLoaded', visadd.onReady, false);
// Bad citizens.
} else if (document.attachEvent) {
document.attachEvent('onreadystatechange', visadd.onReady);
}
// Bad citizens.
// If IE is used and page is not in a frame, continuously check to see if
// the document is ready
if (visadd.utils.isIE() && window === top) {
(function() {
try {
// If IE is used, use the trick by Diego Perini
// http://javascript.nwbox.com/IEContentLoaded/
document.documentElement.doScroll('left');
} catch(error) {
setTimeout(arguments.callee, 0);
return;
}
// and execute any waiting functions
visadd.onReady();
})();
}
// Ultimate Fallback.
var oldonload = window.onload;
window.onload = function() {
visadd.onReady();
if (oldonload) {
if (typeof oldonload == 'string') {
eval(oldonload);
} else {
oldonload();
}
}
};
})();
/****************************************************************************************************************/
})();
